# BOG-Pack
If you already have this, I don't recommend downloading this file.  Instructions: Step 1: Look for this ZIP file on GitHub. Step 2: Download it. Step 3: Read this file. Step 4: Exract the file if you get a message. Step 5: Go to MCE and press "Import", then press open on the file called "Blocks of Grass Pack" and import. Step 6: Play!
